/**
 * Test entry point — imports every *.test.ts file so `npm test` works on
 * Node 20+ (which does not auto-discover .ts files) and on all platforms.
 */
import './remoteLearningSurvey.test';
import './reportsCenter.test';
import './certificates.test';
import './impact.test';
import './impact-import.test';
import './attendance.test';
import './behavior.test';
import './notifications.test';
import './me.test';
import './outcomes.test';
import './program-report.test';
import './cohorts.test';
import './audit.test';
import './health.test';
import './access.test';
import './templates.test';
import './readiness.test';
import './backup.test';
import './portal.test';
import './catalog.test';
import './payments.test';
import './webhook.test';
import './consulting.test';
import './resources.test';
import './live.test';
import './placement.test';
import './profile.test';
import './org.test';
import './sector-impact.test';
import './ai-athar.test';
import './sim.test';
import './twin.test';
import './missions.test';
import './contracts.test';
import './p13.test';
import './p13b.test';
import './p13c.test';
import './p14.test';
import './p15.test';
import './p16.test';
import './p17.test';
import './p18.test';

import './p19.test';
import './p20.test';
import './p21.test';
import './p22.test';
import './p23.test';
